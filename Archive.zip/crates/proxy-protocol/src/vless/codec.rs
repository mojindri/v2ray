//! VLESS wire format: encoding and decoding the request/response headers.
//!
//! # Request format (client → server)
//!
//! ```text
//! ┌──────────┬────────────────┬───────────────┬───────────┬──────────────┬──────────────────────┐
//! │ VER (1B) │  UUID (16B)    │ ADDONS_LEN(1B)│ ADDONS(N) │   CMD (1B)   │ PORT+ADDR+PAYLOAD... │
//! └──────────┴────────────────┴───────────────┴───────────┴──────────────┴──────────────────────┘
//! ```
//!
//! - **VER**: Always 0x00. If 0x01 is received, it is a future version — reject it.
//! - **UUID**: 16 raw bytes (not the hyphenated string form). Used to identify the user.
//! - **ADDONS_LEN**: Length of the optional addons field. Usually 0 in Phase 1.
//!   When non-zero, contains protobuf-encoded data including the `flow` field
//!   (e.g. `"xtls-rprx-vision"` for the XTLS Vision splice mode).
//! - **CMD**: 0x01 = TCP CONNECT, 0x02 = UDP ASSOCIATE, 0x03 = Mux.Cool (deprecated).
//! - **PORT**: 2 bytes, big-endian.
//! - **ATYP**: 0x01 = IPv4 (4 bytes), 0x02 = domain (1-byte len + bytes), 0x03 = IPv6 (16 bytes).
//!
//! # Response format (server → client)
//!
//! ```text
//! ┌──────────┬───────────────┬───────────┐
//! │ VER (1B) │ ADDONS_LEN(1B)│ ADDONS(N) │  then raw payload immediately
//! └──────────┴───────────────┴───────────┘
//! ```
//!
//! The response header is minimal — version byte, then addons length (usually 0),
//! then raw bytes. There is no per-chunk framing in the payload.
//!
//! # Source
//!
//! Wire format defined in XTLS/Xray-core `proxy/vless/encoding/encoding.go`.

use bytes::{BufMut, Bytes, BytesMut};
use tokio::io::{AsyncRead, AsyncReadExt};

use proxy_common::{Address, ProxyError};

// ── Command byte constants ────────────────────────────────────────────────────

/// VLESS command: open a TCP connection to the destination.
pub const CMD_TCP: u8 = 0x01;

/// VLESS command: UDP association (not implemented in Phase 1).
pub const CMD_UDP: u8 = 0x02;

// ── Address type constants ────────────────────────────────────────────────────

/// Address type: IPv4 — the next 4 bytes are the IPv4 address.
const ATYP_IPV4: u8 = 0x01;

/// Address type: domain name — the next byte is the length, then the name bytes.
const ATYP_DOMAIN: u8 = 0x02;

/// Address type: IPv6 — the next 16 bytes are the IPv6 address.
const ATYP_IPV6: u8 = 0x03;

/// The only supported VLESS version. Reject any other value.
const VLESS_VERSION: u8 = 0x00;

// ── Decoded request ───────────────────────────────────────────────────────────

/// A decoded VLESS request header.
#[derive(Debug)]
pub struct VlessRequest {
    /// The 16-byte user UUID extracted from the header.
    pub uuid: [u8; 16],

    /// The command: TCP connect or UDP associate.
    pub command: Command,

    /// The destination the client wants to reach.
    pub dest: Address,

    /// The optional `flow` string from the addons field.
    /// "xtls-rprx-vision" means the client wants XTLS Vision splice mode.
    /// Empty string means no special flow.
    pub flow: String,
}

/// VLESS command byte decoded into an enum for clarity.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Command {
    /// Open a TCP connection to the destination.
    Tcp,
    /// UDP association (Phase 1: not fully implemented).
    Udp,
}

// ── Decoder ───────────────────────────────────────────────────────────────────

/// Read and decode a VLESS request header from an async byte stream.
///
/// After this function returns, the stream is positioned at the start of the
/// raw payload — ready for bidirectional relay with the destination.
///
/// # Errors
///
/// Returns `ProxyError::Protocol` if:
///   - The version byte is not 0x00
///   - The command byte is not 0x01 or 0x02
///   - The address type is unknown
///   - The domain name is not valid UTF-8
///   - The stream ended unexpectedly (e.g. client disconnected mid-header)
pub async fn decode_request<R: AsyncRead + Unpin>(
    reader: &mut R,
) -> Result<VlessRequest, ProxyError> {
    // Read version byte.
    let ver = reader.read_u8().await?;
    if ver != VLESS_VERSION {
        return Err(ProxyError::Protocol(format!(
            "VLESS version {ver:#x} not supported"
        )));
    }

    // Read UUID (16 bytes).
    let mut uuid = [0u8; 16];
    reader.read_exact(&mut uuid).await?;

    // Read addons length and the addons bytes.
    // In Phase 1 we read the bytes but only look for the `flow` field.
    let addons_len = reader.read_u8().await? as usize;
    let flow = if addons_len > 0 {
        let mut addons_buf = vec![0u8; addons_len];
        reader.read_exact(&mut addons_buf).await?;
        // Parse the `flow` field from the protobuf addons.
        // The addons message has field 1 = flow (string).
        // We do a minimal parse rather than pulling in a full protobuf crate.
        parse_flow_from_addons(&addons_buf)
    } else {
        String::new()
    };

    // Read command byte.
    let cmd_byte = reader.read_u8().await?;
    let command = match cmd_byte {
        CMD_TCP => Command::Tcp,
        CMD_UDP => Command::Udp,
        other => {
            return Err(ProxyError::Protocol(format!(
                "unknown VLESS CMD {other:#x}"
            )));
        }
    };

    // Read port (2 bytes, big-endian).
    let port = reader.read_u16().await?;

    // Read address type and address.
    let atyp = reader.read_u8().await?;
    let dest = read_address(reader, atyp, port).await?;

    Ok(VlessRequest {
        uuid,
        command,
        dest,
        flow,
    })
}

/// Read a destination address based on the ATYP byte.
async fn read_address<R: AsyncRead + Unpin>(
    reader: &mut R,
    atyp: u8,
    port: u16,
) -> Result<Address, ProxyError> {
    match atyp {
        ATYP_IPV4 => {
            let mut buf = [0u8; 4];
            reader.read_exact(&mut buf).await?;
            Ok(Address::Ipv4(std::net::Ipv4Addr::from(buf), port))
        }
        ATYP_IPV6 => {
            let mut buf = [0u8; 16];
            reader.read_exact(&mut buf).await?;
            Ok(Address::Ipv6(std::net::Ipv6Addr::from(buf), port))
        }
        ATYP_DOMAIN => {
            // Domain: 1-byte length prefix + name bytes.
            let len = reader.read_u8().await? as usize;
            let mut name = vec![0u8; len];
            reader.read_exact(&mut name).await?;
            let domain = String::from_utf8(name)
                .map_err(|_| ProxyError::Protocol("domain name is not valid UTF-8".into()))?;
            Ok(Address::Domain(domain, port))
        }
        other => Err(ProxyError::Protocol(format!(
            "unknown VLESS ATYP {other:#x}"
        ))),
    }
}

/// Minimal protobuf parser for the VLESS addons field.
///
/// The addons message has one field: field 1 = flow (string).
/// Protobuf encoding: field_number (3 bits) + wire_type (3 bits) in a varint,
/// followed by a length-prefixed string for string fields.
///
/// We only look for field 1 (the flow string) and ignore everything else.
fn parse_flow_from_addons(data: &[u8]) -> String {
    let mut cursor = 0usize;
    while cursor < data.len() {
        // Read the tag varint (field number + wire type).
        // For small values (< 128), a varint is a single byte.
        let tag = data[cursor];
        cursor += 1;

        // wire_type = lower 3 bits; field_number = upper 5 bits (for 1-byte varints)
        let wire_type = tag & 0x07;
        let field_number = tag >> 3;

        // Wire type 2 = length-delimited (string, bytes, embedded message).
        if wire_type == 2 {
            if cursor >= data.len() {
                break;
            }
            let len = data[cursor] as usize;
            cursor += 1;
            if cursor + len > data.len() {
                break;
            }

            if field_number == 1 {
                // Field 1 is the flow string.
                if let Ok(s) = std::str::from_utf8(&data[cursor..cursor + len]) {
                    return s.to_string();
                }
            }
            cursor += len;
        } else {
            // Skip unknown wire types by breaking — we don't need them.
            break;
        }
    }
    String::new()
}

// ── Encoder ───────────────────────────────────────────────────────────────────

/// Encode a VLESS request header into bytes.
///
/// Used by the client (outbound) when connecting to a VLESS server.
/// Returns the header bytes — the caller should send these, then send
/// the payload bytes immediately after.
///
/// # Arguments
/// * `uuid`    — the 16-byte user UUID
/// * `flow`    — optional flow string (e.g. "xtls-rprx-vision"); empty for normal connections
/// * `command` — TCP or UDP
/// * `dest`    — the destination address and port
pub fn encode_request(uuid: &[u8; 16], flow: &str, command: Command, dest: &Address) -> Bytes {
    let mut buf = BytesMut::with_capacity(256);

    // Version byte.
    buf.put_u8(VLESS_VERSION);

    // UUID (16 bytes).
    buf.put_slice(uuid);

    // Addons field.
    if flow.is_empty() {
        // No addons — length = 0.
        buf.put_u8(0);
    } else {
        // Encode the flow field as a minimal protobuf message.
        // Field 1, wire type 2 (length-delimited): tag byte = (1 << 3) | 2 = 0x0A
        let flow_bytes = flow.as_bytes();
        // Total addons length: 1 (tag) + 1 (length) + flow_bytes.len()
        let addons_len = 2 + flow_bytes.len();
        buf.put_u8(addons_len as u8);
        buf.put_u8(0x0A); // field 1, wire type 2
        buf.put_u8(flow_bytes.len() as u8); // string length
        buf.put_slice(flow_bytes); // the string
    }

    // Command byte.
    buf.put_u8(match command {
        Command::Tcp => CMD_TCP,
        Command::Udp => CMD_UDP,
    });

    // Port (2 bytes, big-endian).
    buf.put_u16(dest.port());

    // Address type and address.
    match dest {
        Address::Ipv4(ip, _) => {
            buf.put_u8(ATYP_IPV4);
            buf.put_slice(&ip.octets());
        }
        Address::Ipv6(ip, _) => {
            buf.put_u8(ATYP_IPV6);
            buf.put_slice(&ip.octets());
        }
        Address::Domain(name, _) => {
            buf.put_u8(ATYP_DOMAIN);
            buf.put_u8(name.len() as u8);
            buf.put_slice(name.as_bytes());
        }
    }

    buf.freeze()
}

/// Encode a VLESS response header (server → client).
///
/// The response header is minimal: just version (0) and addons length (0).
/// After sending this, raw payload bytes follow.
pub fn encode_response() -> Bytes {
    // VER=0, ADDONS_LEN=0
    Bytes::from_static(&[VLESS_VERSION, 0x00])
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::net::Ipv4Addr;

    // Helper: decode a request from a byte slice.
    async fn decode_from_bytes(data: &[u8]) -> Result<VlessRequest, ProxyError> {
        let mut cursor = std::io::Cursor::new(data);
        decode_request(&mut cursor).await
    }

    // Checks that a valid VLESS TCP request to an IPv4 address is decoded correctly.
    // These bytes represent a connection to 93.184.216.34:443 (example.com).
    #[tokio::test]
    async fn decode_tcp_ipv4() {
        let uuid = [0xABu8; 16];
        let mut data = vec![
            0x00, // VER = 0
        ];
        data.extend_from_slice(&uuid);
        data.push(0x00); // ADDONS_LEN = 0
        data.push(CMD_TCP); // CMD = TCP
        data.extend_from_slice(&443u16.to_be_bytes()); // PORT = 443
        data.push(ATYP_IPV4); // ATYP = IPv4
        data.extend_from_slice(&[93, 184, 216, 34]); // 93.184.216.34

        let req = decode_from_bytes(&data).await.unwrap();

        assert_eq!(req.uuid, uuid);
        assert_eq!(req.command, Command::Tcp);
        assert_eq!(
            req.dest,
            Address::Ipv4(Ipv4Addr::new(93, 184, 216, 34), 443)
        );
        assert!(req.flow.is_empty());
    }

    // Checks that a VLESS request with a domain address is decoded correctly.
    #[tokio::test]
    async fn decode_tcp_domain() {
        let uuid = [0x11u8; 16];
        let domain = b"example.com";
        let mut data = vec![0x00]; // VER
        data.extend_from_slice(&uuid);
        data.push(0x00); // ADDONS_LEN = 0
        data.push(CMD_TCP); // CMD
        data.extend_from_slice(&443u16.to_be_bytes());
        data.push(ATYP_DOMAIN); // ATYP = domain
        data.push(domain.len() as u8);
        data.extend_from_slice(domain);

        let req = decode_from_bytes(&data).await.unwrap();
        assert_eq!(req.dest, Address::Domain("example.com".into(), 443));
    }

    // Checks that an unsupported version byte returns a Protocol error.
    #[tokio::test]
    async fn unknown_version_returns_error() {
        let data = [0x01u8]; // VER = 1, not supported
        let result = decode_from_bytes(&data).await;
        assert!(matches!(result, Err(ProxyError::Protocol(_))));
    }

    // Checks that an empty/truncated input returns an error (not a panic).
    #[tokio::test]
    async fn truncated_input_returns_error() {
        let result = decode_from_bytes(&[]).await;
        assert!(result.is_err());

        let result = decode_from_bytes(&[0x00]).await;
        assert!(result.is_err());
    }

    // Checks that encode_request + decode_request is a roundtrip.
    // Encoding then decoding must give back the same values.
    #[tokio::test]
    async fn encode_decode_roundtrip_ipv4() {
        let uuid = [0xCCu8; 16];
        let dest = Address::Ipv4(Ipv4Addr::new(1, 2, 3, 4), 8080);
        let encoded = encode_request(&uuid, "", Command::Tcp, &dest);

        let decoded = decode_from_bytes(&encoded).await.unwrap();
        assert_eq!(decoded.uuid, uuid);
        assert_eq!(decoded.command, Command::Tcp);
        assert_eq!(decoded.dest, dest);
        assert!(decoded.flow.is_empty());
    }

    // Checks that a domain name roundtrips correctly.
    #[tokio::test]
    async fn encode_decode_roundtrip_domain() {
        let uuid = [0xDDu8; 16];
        let dest = Address::Domain("proxy.example.com".into(), 443);
        let encoded = encode_request(&uuid, "", Command::Tcp, &dest);
        let decoded = decode_from_bytes(&encoded).await.unwrap();
        assert_eq!(decoded.dest, dest);
    }

    // Checks that the flow field survives an encode-decode roundtrip.
    #[tokio::test]
    async fn flow_field_roundtrip() {
        let uuid = [0xEEu8; 16];
        let dest = Address::Domain("example.com".into(), 443);
        let encoded = encode_request(&uuid, "xtls-rprx-vision", Command::Tcp, &dest);
        let decoded = decode_from_bytes(&encoded).await.unwrap();
        assert_eq!(decoded.flow, "xtls-rprx-vision");
    }
}
