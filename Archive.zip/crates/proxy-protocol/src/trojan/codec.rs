//! Trojan wire format: header encoding and decoding.
//!
//! # Trojan request format (client → server)
//!
//! ```text
//! ┌────────────────────────────────────────────────────────────────────────┐
//! │ SHA224(password_hex_utf8)[56 bytes] + "\r\n"                           │
//! │ CMD(1) + ATYP(1) + ADDR + PORT(2 big-endian) + "\r\n"                  │
//! │ PAYLOAD...                                                              │
//! └────────────────────────────────────────────────────────────────────────┘
//! ```
//!
//! ## Authentication token
//!
//! The SHA-224 digest is computed over the password string:
//!
//! ```text
//! token = lowercase_hex(SHA224(password.as_bytes()))
//! ```
//!
//! This produces a 56-character lowercase hex string, which is sent as the
//! first 56 bytes of every connection, followed by `\r\n`.
//!
//! ## Address encoding (SOCKS5 style)
//!
//! | ATYP | Meaning  | Address bytes          |
//! |------|----------|------------------------|
//! | 0x01 | IPv4     | 4 bytes                |
//! | 0x03 | Domain   | 1-byte len + name bytes|
//! | 0x04 | IPv6     | 16 bytes               |
//!
//! After the address, 2 bytes of big-endian port, then `\r\n`.

use bytes::{BufMut, Bytes, BytesMut};
use sha2::{Digest, Sha224};
use tokio::io::{AsyncRead, AsyncReadExt};

use proxy_common::{Address, ProxyError};

// ── Constants ─────────────────────────────────────────────────────────────────

/// Length of a Trojan auth token: SHA224 produces 28 bytes → 56 hex chars.
pub const TOKEN_LEN: usize = 56;

/// ATYP byte: IPv4.
pub const ATYP_IPV4: u8 = 0x01;

/// ATYP byte: domain name.
pub const ATYP_DOMAIN: u8 = 0x03;

/// ATYP byte: IPv6.
pub const ATYP_IPV6: u8 = 0x04;

/// Trojan command byte for TCP CONNECT.
pub const CMD_CONNECT: u8 = 0x01;

// ── Token computation ─────────────────────────────────────────────────────────

/// Compute the 56-character lowercase hex token for a Trojan password.
///
/// The token is `lowercase_hex(SHA224(password.as_bytes()))`.
pub fn compute_token(password: &str) -> String {
    let mut hasher = Sha224::new();
    hasher.update(password.as_bytes());
    let digest = hasher.finalize();
    hex::encode(digest)
}

// ── Decoder ───────────────────────────────────────────────────────────────────

/// Decoded Trojan request header.
#[derive(Debug)]
pub struct TrojanRequest {
    /// The 56-byte auth token (hex-encoded SHA224 of the password).
    pub token: [u8; TOKEN_LEN],

    /// The destination address the client wants to reach.
    pub dest: Address,
}

/// Read and decode a Trojan request header from an async stream.
///
/// After this function returns, the stream is positioned at the first byte of
/// the payload — ready for bidirectional relay.
pub async fn decode_request<R: AsyncRead + Unpin>(
    reader: &mut R,
) -> Result<TrojanRequest, ProxyError> {
    // Read the 56-byte token.
    let mut token = [0u8; TOKEN_LEN];
    reader.read_exact(&mut token).await?;

    // Read and discard the "\r\n" separator.
    let mut crlf = [0u8; 2];
    reader.read_exact(&mut crlf).await?;
    if crlf != [b'\r', b'\n'] {
        return Err(ProxyError::Protocol(
            "Trojan: expected CRLF after token".into(),
        ));
    }

    let command = reader.read_u8().await?;
    if command != CMD_CONNECT {
        return Err(ProxyError::Protocol(format!(
            "Trojan: unsupported command {command:#x}"
        )));
    }

    // Read address type.
    let atyp = reader.read_u8().await?;
    let dest = read_address(reader, atyp).await?;

    // Read and discard the trailing "\r\n".
    reader.read_exact(&mut crlf).await?;
    if crlf != [b'\r', b'\n'] {
        return Err(ProxyError::Protocol(
            "Trojan: expected CRLF after address".into(),
        ));
    }

    Ok(TrojanRequest { token, dest })
}

/// Read a SOCKS5-style destination address from the stream.
async fn read_address<R: AsyncRead + Unpin>(
    reader: &mut R,
    atyp: u8,
) -> Result<Address, ProxyError> {
    match atyp {
        ATYP_IPV4 => {
            let mut buf = [0u8; 4];
            reader.read_exact(&mut buf).await?;
            let port = reader.read_u16().await?;
            Ok(Address::Ipv4(std::net::Ipv4Addr::from(buf), port))
        }
        ATYP_IPV6 => {
            let mut buf = [0u8; 16];
            reader.read_exact(&mut buf).await?;
            let port = reader.read_u16().await?;
            Ok(Address::Ipv6(std::net::Ipv6Addr::from(buf), port))
        }
        ATYP_DOMAIN => {
            let len = reader.read_u8().await? as usize;
            let mut name = vec![0u8; len];
            reader.read_exact(&mut name).await?;
            let port = reader.read_u16().await?;
            let domain = String::from_utf8(name).map_err(|_| {
                ProxyError::Protocol("Trojan: domain name is not valid UTF-8".into())
            })?;
            Ok(Address::Domain(domain, port))
        }
        other => Err(ProxyError::Protocol(format!(
            "Trojan: unknown ATYP {other:#x}"
        ))),
    }
}

// ── Encoder ───────────────────────────────────────────────────────────────────

/// Encode a Trojan request header into bytes.
///
/// The caller should write these bytes to the server stream immediately,
/// followed by the payload.
///
/// # Arguments
/// * `token` — the 56-char hex token string (from `compute_token`)
/// * `dest`  — the destination address and port
pub fn encode_request(token: &str, dest: &Address) -> Bytes {
    let mut buf = BytesMut::with_capacity(128);

    // Auth token (56 ASCII hex chars).
    buf.put_slice(token.as_bytes());

    // CRLF after token.
    buf.put_slice(b"\r\n");

    // TCP CONNECT command.
    buf.put_u8(CMD_CONNECT);

    // Address.
    encode_address(&mut buf, dest);

    // CRLF after address.
    buf.put_slice(b"\r\n");

    buf.freeze()
}

/// Encode a SOCKS5-style address into the buffer.
fn encode_address(buf: &mut BytesMut, dest: &Address) {
    match dest {
        Address::Ipv4(ip, port) => {
            buf.put_u8(ATYP_IPV4);
            buf.put_slice(&ip.octets());
            buf.put_u16(*port);
        }
        Address::Ipv6(ip, port) => {
            buf.put_u8(ATYP_IPV6);
            buf.put_slice(&ip.octets());
            buf.put_u16(*port);
        }
        Address::Domain(name, port) => {
            buf.put_u8(ATYP_DOMAIN);
            buf.put_u8(name.len() as u8);
            buf.put_slice(name.as_bytes());
            buf.put_u16(*port);
        }
    }
}

// ── Unit tests ────────────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;
    use std::net::Ipv4Addr;

    async fn decode_from_bytes(data: &[u8]) -> Result<TrojanRequest, ProxyError> {
        let mut cursor = std::io::Cursor::new(data);
        decode_request(&mut cursor).await
    }

    /// The SHA224 token is a 56-char lowercase hex string.
    #[test]
    fn token_is_56_chars() {
        let t = compute_token("password");
        assert_eq!(t.len(), TOKEN_LEN);
        assert!(t.chars().all(|c| c.is_ascii_hexdigit()));
    }

    /// Known-value test: SHA224("password") in hex.
    #[test]
    fn token_known_value() {
        // SHA224("password") = d63dc919...
        let token = compute_token("password");
        // Verify it is consistent across calls.
        assert_eq!(token, compute_token("password"));
        assert_ne!(token, compute_token("Password"));
    }

    /// Encode a request to an IPv4 address and decode it back.
    #[tokio::test]
    async fn roundtrip_ipv4() {
        let token = compute_token("test-pass");
        let dest = Address::Ipv4(Ipv4Addr::new(1, 2, 3, 4), 8080);
        let encoded = encode_request(&token, &dest);
        let req = decode_from_bytes(&encoded).await.unwrap();

        assert_eq!(req.token, token.as_bytes());
        assert_eq!(req.dest, dest);
    }

    /// Roundtrip for a domain address.
    #[tokio::test]
    async fn roundtrip_domain() {
        let token = compute_token("hello");
        let dest = Address::Domain("example.com".into(), 443);
        let encoded = encode_request(&token, &dest);
        let req = decode_from_bytes(&encoded).await.unwrap();

        assert_eq!(req.dest, dest);
    }

    /// Roundtrip for an IPv6 address.
    #[tokio::test]
    async fn roundtrip_ipv6() {
        let token = compute_token("ipv6test");
        let dest = Address::Ipv6("::1".parse().unwrap(), 9090);
        let encoded = encode_request(&token, &dest);
        let req = decode_from_bytes(&encoded).await.unwrap();

        assert_eq!(req.dest, dest);
    }

    /// Truncated input should return an error.
    #[tokio::test]
    async fn truncated_returns_error() {
        let result = decode_from_bytes(&[0x01, 0x02]).await;
        assert!(result.is_err());
    }
}
